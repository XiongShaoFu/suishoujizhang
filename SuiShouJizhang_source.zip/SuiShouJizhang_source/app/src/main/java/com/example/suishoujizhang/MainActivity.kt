package com.example.suishoujizhang

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF202124)
private val Muted = Color(0xFF858991)
private val Accent = Color(0xFF278567)
private val SurfaceSoft = Color(0xFFF5F6F5)

data class Entry(val title:String, val amount:Double, val income:Boolean, val time:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary=Accent, background=Color.White, surface=Color.White)) {
            AppScreen(
                load = { readEntries() },
                save = { list -> writeEntries(list) }
            )
        } }
    }
    private fun readEntries(): List<Entry> = try {
        val raw=getSharedPreferences("ledger", MODE_PRIVATE).getString("entries","[]") ?: "[]"
        val arr=JSONArray(raw)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { Entry(it.getString("title"),it.getDouble("amount"),it.getBoolean("income"),it.getString("time")) } }
    } catch (_:Exception) { emptyList() }
    private fun writeEntries(list:List<Entry>) {
        val arr=JSONArray()
        list.forEach { e -> arr.put(JSONObject().put("title",e.title).put("amount",e.amount).put("income",e.income).put("time",e.time)) }
        getSharedPreferences("ledger", MODE_PRIVATE).edit().putString("entries",arr.toString()).apply()
    }
}

@Composable
fun AppScreen(load:()->List<Entry>, save:(List<Entry>)->Unit) {
    var entries by remember { mutableStateOf(load()) }
    var showAdd by remember { mutableStateOf(false) }
    var income by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("餐饮") }
    var tab by remember { mutableStateOf(0) }
    val totalOut=entries.filter{!it.income}.sumOf{it.amount}
    val totalIn=entries.filter{it.income}.sumOf{it.amount}
    val fmt=SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
    Surface(Modifier.fillMaxSize(), color=Color.White) {
        Column(Modifier.fillMaxSize().padding(horizontal=22.dp)) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) {
                Text(if(showAdd) "记一笔" else listOf("账本","统计","我的")[tab], fontSize=23.sp, fontWeight=FontWeight.SemiBold, color=Ink)
                Text("本地账本",fontSize=12.sp,color=Muted)
            }
            Spacer(Modifier.height(20.dp))
            if (showAdd) {
                Row(Modifier.fillMaxWidth().background(SurfaceSoft,RoundedCornerShape(14.dp)).padding(4.dp)) {
                    listOf(false,true).forEach { isIn ->
                        Box(Modifier.weight(1f).background(if(income==isIn) Color.White else Color.Transparent,RoundedCornerShape(11.dp)).clickable { income=isIn }.padding(12.dp), contentAlignment=Alignment.Center) {
                            Text(if(isIn)"收入" else "支出", color=if(income==isIn) Accent else Muted, fontWeight=FontWeight.Medium)
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("金额",color=Muted,fontSize=13.sp)
                OutlinedTextField(amount,{amount=it},modifier=Modifier.fillMaxWidth(),placeholder={Text("0.00")},singleLine=true, prefix={Text("¥ ")})
                Spacer(Modifier.height(18.dp))
                Text("分类",color=Muted,fontSize=13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    (if(income) listOf("工资","兼职","其他") else listOf("餐饮","交通","购物","居住","其他")).forEach { c ->
                        FilterChip(selected=category==c,onClick={category=c},label={Text(c)})
                    }
                }
                Spacer(Modifier.height(20.dp))
                Button(onClick={
                    val v=amount.toDoubleOrNull()
                    if(v!=null && v>0) {
                        entries=listOf(Entry(category,v,income,fmt.format(Date())))+entries
                        save(entries); amount=""; showAdd=false
                    }
                },modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(14.dp)) { Text("保存账单") }
                TextButton(onClick={showAdd=false},modifier=Modifier.align(Alignment.CenterHorizontally)) { Text("取消",color=Muted) }
            } else if(tab==0) {
                Column(Modifier.fillMaxWidth().background(SurfaceSoft,RoundedCornerShape(20.dp)).padding(20.dp)) {
                    Text("本月支出",fontSize=13.sp,color=Muted)
                    Spacer(Modifier.height(6.dp))
                    Text("¥ "+String.format(Locale.getDefault(),"%,.2f",totalOut),fontSize=32.sp,fontWeight=FontWeight.SemiBold,color=Ink)
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Column { Text("收入",fontSize=12.sp,color=Muted); Text("¥ "+String.format(Locale.getDefault(),"%.2f",totalIn),fontSize=17.sp,color=Accent,fontWeight=FontWeight.Medium) }
                        Column(horizontalAlignment=Alignment.End) { Text("结余",fontSize=12.sp,color=Muted); Text("¥ "+String.format(Locale.getDefault(),"%.2f",totalIn-totalOut),fontSize=17.sp,color=Ink,fontWeight=FontWeight.Medium) }
                    }
                }
                Spacer(Modifier.height(26.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Text("最近记录",fontSize=17.sp,fontWeight=FontWeight.SemiBold,color=Ink)
                    Text("${entries.size} 笔",fontSize=12.sp,color=Muted)
                }
                Spacer(Modifier.height(10.dp))
                if(entries.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) { Text("还没有账单，记下第一笔吧",color=Muted,fontSize=14.sp) }
                else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)) {
                    items(entries) { e ->
                        Row(Modifier.fillMaxWidth().padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).background(SurfaceSoft,CircleShape),contentAlignment=Alignment.Center) { Text(e.title.take(1),color=Ink,fontWeight=FontWeight.Medium) }
                            Column(Modifier.weight(1f).padding(start=12.dp)) { Text(e.title,color=Ink,fontWeight=FontWeight.Medium); Text(e.time,fontSize=11.sp,color=Muted) }
                            Text((if(e.income)"+ " else "− ")+"¥"+String.format(Locale.getDefault(),"%.2f",e.amount),color=if(e.income)Accent else Ink,fontWeight=FontWeight.Medium)
                        }
                        HorizontalDivider(color=SurfaceSoft)
                    }
                }
            } else {
                Column(Modifier.fillMaxWidth().background(SurfaceSoft,RoundedCornerShape(18.dp)).padding(20.dp)) {
                    Text(if(tab==1)"收支概览" else "数据与隐私",fontSize=17.sp,fontWeight=FontWeight.SemiBold,color=Ink)
                    Spacer(Modifier.height(12.dp))
                    if(tab==1) {
                        Text("累计收入  ¥${String.format(Locale.getDefault(),"%.2f",totalIn)}",color=Accent)
                        Spacer(Modifier.height(8.dp)); Text("累计支出  ¥${String.format(Locale.getDefault(),"%.2f",totalOut)}",color=Ink)
                        Spacer(Modifier.height(8.dp)); Text("当前结余  ¥${String.format(Locale.getDefault(),"%.2f",totalIn-totalOut)}",color=Ink)
                    } else Text("账单仅保存在本机。卸载应用或清除数据前，请先做好备份。",color=Muted,fontSize=14.sp)
                }
                Spacer(Modifier.weight(1f))
            }
            if(!showAdd) {
                HorizontalDivider(color=SurfaceSoft)
                Row(Modifier.fillMaxWidth().height(68.dp),horizontalArrangement=Arrangement.SpaceAround,verticalAlignment=Alignment.CenterVertically) {
                    listOf(Icons.Default.Home,Icons.Default.BarChart,Icons.Default.Person).forEachIndexed { i,ic ->
                        Column(Modifier.clickable { tab=i }.padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                            Icon(ic,null,tint=if(tab==i) Accent else Muted)
                            Text(listOf("账本","统计","我的")[i],fontSize=10.sp,color=if(tab==i) Accent else Muted)
                        }
                    }
                    Box(Modifier.size(46.dp).background(Accent,CircleShape).clickable { showAdd=true }.padding(10.dp),contentAlignment=Alignment.Center) { Icon(Icons.Default.Add,null,tint=Color.White) }
                }
            }
        }
    }
}
